package com.ultragram.android.ui.screens.chats

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.ultragram.android.data.model.Message
import com.ultragram.android.data.network.NetworkModule
import kotlinx.coroutines.launch

@Composable
fun ChatScreen(navController: androidx.navigation.NavController, chatId: String?) {
    var messages by remember { mutableStateOf<List<Message>>(emptyList()) }
    var input by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    LaunchedEffect(chatId) {
        scope.launch {
            try { if (chatId != null) messages = NetworkModule.api.messages(chatId) } catch (_: Exception) {}
        }
    }
    Scaffold(
        topBar = { TopAppBar(title = { Text("Чат") }, navigationIcon = { IconButton(onClick = { navController.popBackStack() }) { Text("<") } }) }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            LazyColumn(Modifier.weight(1f).padding(8.dp)) {
                items(messages) { m ->
                    Text(m.content ?: "", modifier = Modifier.padding(4.dp))
                }
            }
            Row(Modifier.padding(8.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                OutlinedTextField(value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f))
                Spacer(Modifier.width(8.dp))
                Button(onClick = {
                    if (input.isNotBlank() && chatId != null) {
                        scope.launch {
                            try {
                                val msg = NetworkModule.api.sendMessage(chatId, mapOf("content" to input))
                                messages = messages + msg
                                input = ""
                            } catch (_: Exception) {}
                        }
                    }
                }) { Text("➤") }
            }
        }
    }
}
package com.ultragram.android.ui.screens.wallet

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.ultragram.android.data.network.NetworkModule
import kotlinx.coroutines.launch

@Composable
fun WalletScreen(navController: androidx.navigation.NavController) {
    var balance by remember { mutableStateOf(0L) }
    var loading by remember { mutableStateOf(true) }
    val scope = rememberCoroutineScope()
    LaunchedEffect(Unit) {
        scope.launch { try { balance = NetworkModule.api.wallet().balance } catch (_: Exception) {}; loading = false }
    }
    Scaffold(topBar = { TopAppBar(title = { Text("Кошелёк Огоньков") }, navigationIcon = { IconButton(onClick = { navController.popBackStack() }) { Text("<") } }) }) { pad ->
        Column(Modifier.padding(pad).padding(16.dp)) {
            if (loading) CircularProgressIndicator()
            else Text("🔥 $balance", style = MaterialTheme.typography.titleLarge)
        }
    }
}
package com.ultragram.android.ui.screens.gifts

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.ultragram.android.data.model.Gift
import com.ultragram.android.data.network.NetworkModule
import kotlinx.coroutines.launch

@Composable
fun GiftsScreen(navController: androidx.navigation.NavController) {
    var gifts by remember { mutableStateOf<List<Gift>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    val scope = rememberCoroutineScope()
    LaunchedEffect(Unit) {
        scope.launch { try { gifts = NetworkModule.api.gifts() } catch (_: Exception) {}; loading = false }
    }
    Scaffold(topBar = { TopAppBar(title = { Text("Подарки") }, navigationIcon = { IconButton(onClick = { navController.popBackStack() }) { Text("<") } }) }) { pad ->
        if (loading) {
            Box(Modifier.fillMaxSize().padding(pad), contentAlignment = androidx.compose.ui.Alignment.Center) { CircularProgressIndicator() }
        } else {
            LazyColumn(Modifier.padding(pad)) {
                items(gifts) { g ->
                    ListItem(headlineContent = { Text(g.name) }, supportingContent = { Text("${g.rarity} · ${g.price} 🔥") })
                    HorizontalDivider()
                }
            }
        }
    }
}
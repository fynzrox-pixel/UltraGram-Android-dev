package com.ultragram.android.ui.screens.chats

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.ultragram.android.data.model.Chat
import com.ultragram.android.data.network.NetworkModule
import kotlinx.coroutines.launch

@Composable
fun ChatListScreen(navController: androidx.navigation.NavController) {
    var chats by remember { mutableStateOf<List<Chat>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    val scope = rememberCoroutineScope()
    LaunchedEffect(Unit) {
        scope.launch {
            try { chats = NetworkModule.api.chats() } catch (_: Exception) {}
            loading = false
        }
    }
    Scaffold(
        topBar = { TopAppBar(title = { Text("UltraGram") }) }
    ) { pad ->
        if (loading) {
            Box(Modifier.fillMaxSize().padding(pad), contentAlignment = androidx.compose.ui.Alignment.Center) { CircularProgressIndicator() }
        } else {
            LazyColumn(Modifier.padding(pad)) {
                items(chats) { chat ->
                    ListItem(
                        headlineContent = { Text(chat.name ?: "Чат") },
                        supportingContent = { Text(chat.lastMessage?.content ?: "") },
                        modifier = Modifier.clickable { navController.navigate("chat/${chat.id}") }
                    )
                    HorizontalDivider()
                }
            }
        }
    }
}
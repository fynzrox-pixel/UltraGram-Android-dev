package com.ultragram.android.ui.screens.profile

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.ultragram.android.data.network.NetworkModule
import kotlinx.coroutines.launch

@Composable
fun ProfileScreen(navController: androidx.navigation.NavController) {
    var user by remember { mutableStateOf<com.ultragram.android.data.model.User?>(null) }
    val scope = rememberCoroutineScope()
    LaunchedEffect(Unit) {
        scope.launch { try { user = NetworkModule.api.me() } catch (_: Exception) {} }
    }
    Scaffold(topBar = { TopAppBar(title = { Text("Профиль") }, navigationIcon = { IconButton(onClick = { navController.popBackStack() }) { Text("<") } }) }) { pad ->
        Column(Modifier.padding(pad).padding(16.dp)) {
            Text(user?.profile?.displayName ?: "Пользователь", style = MaterialTheme.typography.titleLarge)
            Text("@" + (user?.profile?.username ?: "—"))
            Text(user?.profile?.bio ?: "")
            Spacer(Modifier.height(8.dp))
            Text("Баланс: ${user?.balance ?: 0} 🔥")
            Text("Верификация: ${user?.verification ?: "Unverified"}")
        }
    }
}
package com.ultragram.android.ui.screens.settings

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(navController: androidx.navigation.NavController) {
    Scaffold(topBar = { TopAppBar(title = { Text("Настройки") }, navigationIcon = { IconButton(onClick = { navController.popBackStack() }) { Text("<") } }) }) { pad ->
        Column(Modifier.padding(pad).padding(16.dp)) {
            Text("Тема, уведомления, безопасность, устройства — настраиваются здесь.", style = MaterialTheme.typography.bodyLarge)
        }
    }
}
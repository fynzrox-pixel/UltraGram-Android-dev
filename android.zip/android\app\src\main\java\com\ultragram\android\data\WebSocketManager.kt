package com.ultragram.android.data

import okhttp3.*
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object WebSocketManager {
    private var ws: WebSocket? = null
    private val client = OkHttpClient.Builder()
        .pingInterval(30, TimeUnit.SECONDS)
        .build()
    var onMessage: ((JSONObject) -> Unit)? = null

    fun connect(baseUrl: String, authToken: String) {
        val url = baseUrl.replace("http", "ws") + "ws?token=$authToken"
        val request = Request.Builder().url(url).build()
        ws = client.newWebSocket(request, object : WebSocketListener() {
            override fun onMessage(webSocket: WebSocket, text: String) {
                try { onMessage?.invoke(JSONObject(text)) } catch (_: Exception) {}
            }
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {}
        })
    }

    fun send(payload: String) {
        ws?.send(payload)
    }

    fun disconnect() {
        ws?.close(1000, "bye")
        ws = null
    }
}
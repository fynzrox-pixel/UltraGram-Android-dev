package com.ultragram.android.ui.screens.auth

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.ultragram.android.data.network.NetworkModule
import kotlinx.coroutines.launch

@Composable
fun AuthScreen(navController: androidx.navigation.NavController) {
    var phone by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var password2 by remember { mutableStateOf("") }
    var isRegister by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("UltraGram", style = MaterialTheme.typography.titleLarge, color = com.ultragram.android.ui.theme.UgPrimary)
        Spacer(Modifier.height(24.dp))
        OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("Телефон") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = password, onValueChange = { password = it }, label = { Text("Пароль") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
        if (isRegister) {
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(value = password2, onValueChange = { password2 = it }, label = { Text("Повтор пароля") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
        }
        Spacer(Modifier.height(16.dp))
        if (loading) CircularProgressIndicator()
        else Button(onClick = {
            loading = true; error = null
            scope.launch {
                try {
                    val body = mutableMapOf("phone" to phone, "password" to password)
                    if (isRegister) body["password2"] = password2
                    val resp = if (isRegister) NetworkModule.api.register(body) else NetworkModule.api.login(body)
                    navController.navigate("chats") { popUpTo("auth") { inclusive = true } }
                } catch (e: Exception) {
                    error = e.message
                } finally { loading = false }
            }
        }, modifier = Modifier.fillMaxWidth()) {
            Text(if (isRegister) "Создать аккаунт" else "Войти")
        }
        Spacer(Modifier.height(8.dp))
        TextButton(onClick = { isRegister = !isRegister }) {
            Text(if (isRegister) "Уже есть аккаунт? Войти" else "Нет аккаунта? Регистрация")
        }
        error?.let { Text(it, color = com.ultragram.android.ui.theme.UgDanger) }
    }
}